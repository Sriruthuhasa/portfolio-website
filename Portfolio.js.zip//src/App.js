import React from "react";

export default function App() {
  return (
    <div
      style={{
        backgroundColor: "#0f172a",
        color: "white",
        minHeight: "100vh",
        padding: "40px",
        fontFamily: "sans-serif",
      }}
    >
      <header style={{ textAlign: "center", marginBottom: "50px" }}>
        <h1 style={{ color: "#60a5fa", fontSize: "3rem" }}>
          Sri Ruthuhasa Komma
        </h1>
        <p style={{ fontSize: "1.2rem", color: "#94a3b8" }}>
          CS Graduate Student | Full-Stack Developer
        </p>
      </header>

      <div style={{ maxWidth: "800px", margin: "0 auto" }}>
        <section
          style={{
            background: "#1e293b",
            padding: "20px",
            borderRadius: "12px",
            marginBottom: "20px",
            border: "1px solid #334155",
          }}
        >
          <h2 style={{ color: "#34d399" }}>Web Developer @ WebxInfinity</h2>
          <p>
            Boosted page speed and performance by 30% through SEO and caching.
          </p>
        </section>

        <section
          style={{
            background: "#1e293b",
            padding: "20px",
            borderRadius: "12px",
            border: "1px solid #334155",
          }}
        >
          <h2 style={{ color: "#34d399" }}>
            Process Mining Intern @ EduSkills
          </h2>
          <p>
            Utilized Celonis to transform raw system data into business
            intelligence.
          </p>
        </section>
      </div>
    </div>
  );
}
